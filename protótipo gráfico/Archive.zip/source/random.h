#ifndef __RANDOM
#define __RANDOM

#include <cstdlib>
#include <ctime>

int randomize (int i, int j);

#endif

