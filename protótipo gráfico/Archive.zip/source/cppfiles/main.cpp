#include "../classmain.h"

int main()
{
    Main myGame;
    myGame.loop();
    return 0;
}
