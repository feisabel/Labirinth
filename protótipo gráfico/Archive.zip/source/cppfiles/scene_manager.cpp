#include "../scene_manager.h"

Scene* SceneManager::current_scene = NULL;